// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:understanding_firebase/Screens/Home/music_tile.dart';
// import 'package:understanding_firebase/Screens/models/music.dart';


// class BodyData extends StatefulWidget {
//   @override
//   _BodyDataState createState() => _BodyDataState();
// }

// class _BodyDataState extends State<BodyData> {
//   @override
//   Widget build(BuildContext context) {
//   final  music = Provider.of<List<Music>>(context);
//     return ListView(
//       children: []    );
//   }
// }



// ListView.builder(
//       itemCount: music.length,
//       itemBuilder: (context,index){
        
//         return  MusicTile(music: music[index]);}
//     );

