class Music {
final String name;
final String age;
final String type;

Music({required this.age,required this.name,required this.type});
}