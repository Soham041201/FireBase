class AppUser{
  final String uid;
  
  AppUser({ required this.uid });
}