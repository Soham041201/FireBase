import 'package:flutter/material.dart';
  InputDecoration formDesign(String text) {
    
    return InputDecoration(
                hintText: text,
      
              );
  }
 